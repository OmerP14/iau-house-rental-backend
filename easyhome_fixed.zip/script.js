let properties = [];
let currentFilters = {
  city: ""
};

document.addEventListener("DOMContentLoaded", () => {
  setupFilters();
  fetchProperties();
});

function setupFilters() {
  const cityFilter = document.getElementById("filter-city");
  cityFilter.addEventListener("change", (e) => {
    currentFilters.city = e.target.value;
    renderProperties();
  });
}

async function fetchProperties() {
  try {
    const res = await fetch("https://easyhome-ayu6.onrender.com/api/listings");
    const data = await res.json();
    properties = data;
    renderProperties();
  } catch (error) {
    console.error("İlanlar alınamadı:", error);
  }
}

function renderProperties() {
  const listingsGrid = document.getElementById("listings-grid");
  if (!listingsGrid) return;
  listingsGrid.innerHTML = "";

  const filtered = properties.filter(p => {
    if (currentFilters.city && p.city.toLowerCase() !== currentFilters.city.toLowerCase()) return false;
    return true;
  });

  if (filtered.length === 0) {
    listingsGrid.innerHTML = "<p>Gösterilecek ilan yok.</p>";
    return;
  }

  filtered.forEach(property => {
    const div = document.createElement("div");
    div.className = "property-card";
    div.innerHTML = `
      <h3>${property.title}</h3>
      <p>${property.city} / ${property.district}</p>
      <p>${property.price} TL</p>
    `;
    listingsGrid.appendChild(div);
  });
}